# AI учител по БЕЛ

Уеб приложение за подготовка за ДЗИ (матура) по български език и литература:
📝 Тест (30 въпроса, 15 език + 15 литература), 🎤 Изпитай ме (устен изпит), ✍️ Провери ми есето, 🎯 Слаби места.

- Next.js + TypeScript + Tailwind, AI: Claude (`claude-sonnet-5-5`) през `@anthropic-ai/sdk`
- Ключът `ANTHROPIC_API_KEY` е само на сървъра; входът е защитен с `APP_PASSWORD`
- Прогресът се пази в браузъра (localStorage)
- Изпитният материал е в `data/syllabus.ts`

## Пускане локално

1. Попълни `.env.local`:
   ```
   ANTHROPIC_API_KEY=sk-ant-...
   APP_PASSWORD=измисли-парола
   ```
2. `npm install`
3. `npm run dev` и отвори http://localhost:3000

## Качване във Vercel (без команден ред)

1. Качи папката в GitHub (нов репозиторий, напр. `bel-uchitel`). Файлът `.env.local` НЕ се качва – така е настроено.
2. Влез в https://vercel.com с GitHub акаунта си → **Add New… → Project** → избери репозиторито → **Import**.
3. Преди **Deploy** отвори **Environment Variables** и добави:
   - `ANTHROPIC_API_KEY` = твоят ключ от https://console.anthropic.com
   - `APP_PASSWORD` = паролата, която ще дадеш на приятелката си
4. Натисни **Deploy**. След ~1 минута получаваш линк (напр. `https://bel-uchitel.vercel.app`).
5. Изпрати линка и паролата. Паролата се въвежда веднъж – браузърът я запомня.

Промяна на ключа или паролата по-късно: Vercel → проекта → **Settings → Environment Variables** → редактирай → **Deployments → … → Redeploy**.

Съвет: в https://console.anthropic.com задай месечен лимит на разходите (Settings → Limits).
