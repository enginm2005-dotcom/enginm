import { timingSafeEqual } from "crypto";

/** Проверява паролата от заглавката x-app-password срещу APP_PASSWORD (само на сървъра). */
export function isAuthorized(req: Request): boolean {
  const expected = process.env.APP_PASSWORD;
  if (!expected) return false; // без зададена парола – никой не влиза
  const given = req.headers.get("x-app-password") ?? "";
  const a = Buffer.from(given, "utf8");
  const b = Buffer.from(expected, "utf8");
  return a.length === b.length && timingSafeEqual(a, b);
}

export function unauthorized() {
  return Response.json({ error: "Грешна парола." }, { status: 401 });
}
