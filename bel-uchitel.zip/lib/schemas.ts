import { z } from "zod";

// ---------- ТЕСТ ----------
export const QuestionSchema = z.object({
  passage: z
    .string()
    .describe("Откъс/текст към задачата (ако има). Празен низ, ако задачата няма откъс."),
  question: z.string().describe("Условието на задачата."),
  options: z
    .array(z.string())
    .describe("Точно 4 варианта БЕЗ буквите а), б), в), г) за избираем отговор; празен масив за кратък отговор."),
  correctIndex: z
    .number()
    .int()
    .describe("Индекс (0–3) на верния вариант; -1 при кратък отговор."),
  correctAnswer: z.string().describe("Верният отговор като текст."),
  acceptableAnswers: z
    .array(z.string())
    .describe("Други приемливи формулировки на верния кратък отговор (може празен)."),
  explanation: z.string().describe("Кратко обяснение ЗАЩО това е верният отговор (1–3 изречения)."),
  topic: z.string().describe("Темата на задачата – точно зададената тема."),
});
export type Question = z.infer<typeof QuestionSchema> & {
  type: "mc" | "short";
  subject: "ezik" | "literatura";
};

export const GradeSchema = z.object({
  correct: z.boolean(),
  feedback: z.string().describe("1–2 изречения: защо е вярно/грешно."),
});
export type Grade = z.infer<typeof GradeSchema>;

// ---------- ИЗПИТАЙ МЕ ----------
export const OralSchema = z.object({
  verdict: z
    .enum(["вярно", "частично", "грешно", "няма"])
    .describe("Оценка на последния отговор на ученичката; „няма“, ако още не е отговаряла."),
  feedback: z
    .string()
    .describe("Оценка на отговора: какво е добре, какво липсва (2–5 изречения). Празно, ако verdict е „няма“."),
  nextQuestion: z.string().describe("Следващият въпрос по зададената тема."),
});
export type OralTurn = z.infer<typeof OralSchema>;

// ---------- ЕСЕ ----------
export const EssayTopicSchema = z.object({
  topic: z.string().describe("Формулировка на темата, както на матурата."),
  hint: z.string().describe("1–2 изречения насока какво се очаква."),
});

export const EssayCheckSchema = z.object({
  criteria: z
    .array(
      z.object({
        name: z.string(),
        points: z.number(),
        max: z.number(),
        comment: z.string(),
      }),
    )
    .describe("Оценка по всеки критерий в зададения ред."),
  errors: z
    .array(
      z.object({
        kind: z.enum(["правопис", "пунктуация", "граматика", "лексика", "стил", "съдържание"]),
        quote: z.string().describe("Точният откъс от текста с грешката."),
        fix: z.string().describe("Правилният вариант."),
        why: z.string().describe("Кратко правило/обяснение."),
      }),
    )
    .describe("Конкретни грешки, цитирани от текста."),
  strengths: z.array(z.string()),
  improvements: z.array(z.string()).describe("Конкретни съвети как да се подобри текстът."),
  summary: z.string().describe("Обобщение в 2–3 изречения."),
  weakTopics: z
    .array(z.string())
    .describe("Езикови теми или произведения, които ученичката трябва да повтори (кратки етикети)."),
});
export type EssayCheck = z.infer<typeof EssayCheckSchema>;
