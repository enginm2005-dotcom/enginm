import "server-only";
import Anthropic from "@anthropic-ai/sdk";
import { betaZodOutputFormat } from "@anthropic-ai/sdk/helpers/beta/zod";
import type { z } from "zod";
import { EXAM_FORMAT, syllabusText } from "@/data/syllabus";

export const MODEL = "claude-sonnet-5-5";

// Ключът се чете от ANTHROPIC_API_KEY само на сървъра.
const client = new Anthropic();

/** Общ системен промпт: стабилен текст (кешира се), съдържа целия конспект. */
export const BASE_SYSTEM = `Ти си „AI учител по БЕЛ“ – добър, търпелив и честен учител, който подготвя ученичка за държавния зрелостен изпит (ДЗИ, матура) по български език и литература.

Правила:
- Пиши САМО на книжовен български език, без правописни и пунктуационни грешки.
- Работи САМО с материала от конспекта по-долу. Не измисляй произведения, автори, герои, цитати или факти. Ако не си сигурен в точния текст на стих или откъс, НЕ го цитирай – питай за смисъл, мотиви, образи, жанр, проблематика.
- Тонът ти е кратък, ясен, насърчителен, но честен: ако отговорът е грешен, казваш го директно и обясняваш защо.
- Въпросите приличат на истинските задачи от ДЗИ.

Формат на изпита: ${EXAM_FORMAT}

КОНСПЕКТ:
${syllabusText()}`;

type Effort = "low" | "medium" | "high";

export class AiError extends Error {}

/**
 * Изпраща заявка към Claude и връща валидиран JSON според Zod схемата.
 * Структурираният изход гарантира формата; при неуспех опитваме още веднъж.
 */
export async function askJson<S extends z.ZodType>(opts: {
  schema: S;
  task: string; // специфични инструкции за задачата (добавят се към системния промпт)
  messages: Anthropic.Beta.BetaMessageParam[];
  effort?: Effort;
  maxTokens?: number;
}): Promise<z.infer<S>> {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const response = await client.beta.messages.parse({
        model: MODEL,
        max_tokens: opts.maxTokens ?? 8000,
        betas: ["server-side-fallback-2026-07-01"],
        fallbacks: "default",
        system: [
          { type: "text", text: BASE_SYSTEM, cache_control: { type: "ephemeral" } },
          { type: "text", text: opts.task },
        ],
        output_config: {
          effort: opts.effort ?? "low",
          format: betaZodOutputFormat(opts.schema),
        },
        messages: opts.messages,
      });

      if (response.stop_reason === "refusal") {
        throw new AiError("AI учителят отказа да отговори на тази заявка. Опитай отново.");
      }
      const parsed = opts.schema.safeParse(response.parsed_output);
      if (parsed.success) return parsed.data;
    } catch (err) {
      if (err instanceof AiError) throw err;
      if (err instanceof Anthropic.AuthenticationError) {
        throw new AiError("Невалиден ANTHROPIC_API_KEY на сървъра.");
      }
      if (err instanceof Anthropic.RateLimitError) {
        throw new AiError("Твърде много заявки. Изчакай малко и опитай пак.");
      }
      if (attempt === 1) {
        console.error("AI error:", err);
        throw new AiError("AI учителят не отговори. Провери връзката и опитай пак.");
      }
    }
  }
  throw new AiError("AI учителят върна неочакван отговор. Опитай пак.");
}

/** Обща обработка на грешки за API маршрутите. */
export function errorResponse(err: unknown) {
  const message = err instanceof AiError ? err.message : "Възникна грешка на сървъра.";
  if (!(err instanceof AiError)) console.error(err);
  return Response.json({ error: message }, { status: 500 });
}
