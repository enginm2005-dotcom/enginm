"use client";

import { languageTopics, literature, literatureTopics, workLabel, type Subject } from "@/data/syllabus";

// ---------- Парола ----------
const PW_KEY = "bel.password";

export function getPassword(): string | null {
  try {
    return localStorage.getItem(PW_KEY);
  } catch {
    return null;
  }
}
export function setPassword(pw: string) {
  try {
    localStorage.setItem(PW_KEY, pw);
  } catch {}
}
export function clearPassword() {
  try {
    localStorage.removeItem(PW_KEY);
  } catch {}
}

export class AuthError extends Error {}

/** POST към нашите API маршрути с паролата в заглавката. */
export async function api<T>(path: string, body: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-app-password": getPassword() ?? "" },
      body: JSON.stringify(body),
    });
  } catch {
    throw new Error("Няма връзка със сървъра. Провери интернета.");
  }
  if (res.status === 401) {
    clearPassword();
    window.dispatchEvent(new Event("bel-auth-required"));
    throw new AuthError("Грешна парола.");
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error ?? "Възникна грешка.");
  return data as T;
}

// ---------- Прогрес и слаби места ----------
export type TopicStat = { subject: Subject; right: number; wrong: number; last: number };
export type Progress = {
  stats: Record<Subject, { correct: number; total: number }>;
  topics: Record<string, TopicStat>;
};

const PROGRESS_KEY = "bel.progress.v1";

function emptyProgress(): Progress {
  return {
    stats: { ezik: { correct: 0, total: 0 }, literatura: { correct: 0, total: 0 } },
    topics: {},
  };
}

export function loadProgress(): Progress {
  try {
    const raw = localStorage.getItem(PROGRESS_KEY);
    if (!raw) return emptyProgress();
    const p = JSON.parse(raw) as Progress;
    if (!p.stats || !p.topics) return emptyProgress();
    return p;
  } catch {
    return emptyProgress();
  }
}

function saveProgress(p: Progress) {
  try {
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(p));
  } catch {}
}

export function resetProgress() {
  saveProgress(emptyProgress());
}

/** Записва резултат от въпрос. countInStats=false – само за слабите места (напр. от есе). */
export function recordResult(subject: Subject, topic: string, correct: boolean, countInStats = true) {
  const p = loadProgress();
  if (countInStats) {
    p.stats[subject].total += 1;
    if (correct) p.stats[subject].correct += 1;
  }
  const t = p.topics[topic] ?? { subject, right: 0, wrong: 0, last: 0 };
  if (correct) t.right += 1;
  else t.wrong += 1;
  t.last = Date.now();
  p.topics[topic] = t;
  saveProgress(p);
}

/** „Слабост“ на тема: колко повече грешки, отколкото верни отговори. */
function weakness(t: TopicStat | undefined): number {
  if (!t) return 0;
  return Math.max(0, t.wrong - 0.6 * t.right);
}

export function weakTopics(limit = 50): { topic: string; stat: TopicStat; pct: number }[] {
  const p = loadProgress();
  return Object.entries(p.topics)
    .filter(([, s]) => weakness(s) > 0)
    .sort((a, b) => weakness(b[1]) - weakness(a[1]) || b[1].last - a[1].last)
    .slice(0, limit)
    .map(([topic, stat]) => ({
      topic,
      stat,
      pct: Math.round((100 * stat.right) / Math.max(1, stat.right + stat.wrong)),
    }));
}

/**
 * Избира тема от конспекта. Темите, в които греши, имат по-голяма тежест,
 * а наскоро използваните се избягват.
 */
export function pickTopic(subject: Subject, avoid: string[] = []): string {
  const all = subject === "ezik" ? languageTopics() : literatureTopics();
  const p = loadProgress();
  const pool = all.filter((t) => !avoid.includes(t));
  const candidates = pool.length ? pool : all;
  const weights = candidates.map((t) => 1 + 3 * Math.min(weakness(p.topics[t]), 4));
  const sum = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * sum;
  for (let i = 0; i < candidates.length; i++) {
    r -= weights[i];
    if (r <= 0) return candidates[i];
  }
  return candidates[candidates.length - 1];
}

/** Свързва свободен етикет (напр. от проверката на есе) с тема от конспекта. */
export function normalizeLabel(label: string): { subject: Subject; topic: string } {
  const l = label.toLowerCase();
  for (const core of literature) {
    for (const w of core.works) {
      if (l.includes(w.title.toLowerCase())) return { subject: "literatura", topic: workLabel(w) };
    }
  }
  const lang = languageTopics().find((t) => t.toLowerCase() === l);
  return { subject: "ezik", topic: lang ?? label };
}

// ---------- Оценка по шестобалната система ----------
export function sixPointGrade(points: number, max: number): { value: number; label: string } {
  const pct = max > 0 ? points / max : 0;
  const value = pct < 0.23 ? 2 : Math.min(6, Math.max(3, 2 + 4 * pct));
  const label =
    value < 3 ? "Слаб" : value < 3.5 ? "Среден" : value < 4.5 ? "Добър" : value < 5.5 ? "Много добър" : "Отличен";
  return { value: Math.round(value * 100) / 100, label };
}

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
