"use client";

import { useEffect, useState } from "react";
import { getPassword } from "@/lib/client";
import Login from "@/components/Login";
import Home from "@/components/Home";
import Test from "@/components/Test";
import Oral from "@/components/Oral";
import Essay from "@/components/Essay";
import Weak from "@/components/Weak";

export type Screen = "home" | "test" | "oral" | "essay" | "weak";

export default function App() {
  const [ready, setReady] = useState(false);
  const [authed, setAuthed] = useState(false);
  const [screen, setScreen] = useState<Screen>("home");

  useEffect(() => {
    setAuthed(!!getPassword());
    setReady(true);
    const onAuth = () => setAuthed(false);
    window.addEventListener("bel-auth-required", onAuth);
    return () => window.removeEventListener("bel-auth-required", onAuth);
  }, []);

  // Бутонът „назад“ на телефона връща към началния екран.
  useEffect(() => {
    const onPop = () => setScreen("home");
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  const go = (s: Screen) => {
    if (s !== "home") history.pushState({ s }, "");
    setScreen(s);
    window.scrollTo(0, 0);
  };
  const home = () => {
    if (history.state?.s) history.back();
    else setScreen("home");
  };

  if (!ready) return null;
  if (!authed) return <Login onSuccess={() => setAuthed(true)} />;

  switch (screen) {
    case "test":
      return <Test onExit={home} />;
    case "oral":
      return <Oral onExit={home} />;
    case "essay":
      return <Essay onExit={home} />;
    case "weak":
      return <Weak onExit={home} />;
    default:
      return <Home go={go} />;
  }
}
