import { z } from "zod";
import { askJson, errorResponse } from "@/lib/ai";
import { isAuthorized, unauthorized } from "@/lib/auth";
import { QuestionSchema, type Question } from "@/lib/schemas";
import { findWork, topicsFor } from "@/data/syllabus";

export const maxDuration = 60;

const Body = z.object({
  subject: z.enum(["ezik", "literatura"]),
  topic: z.string().max(200),
  type: z.enum(["mc", "short"]),
  recent: z.array(z.string().max(500)).max(40).default([]),
});

function isValid(q: z.infer<typeof QuestionSchema>, type: "mc" | "short") {
  if (!q.question.trim() || !q.explanation.trim()) return false;
  if (type === "mc") {
    return (
      q.options.length === 4 &&
      q.options.every((o) => o.trim().length > 0) &&
      new Set(q.options.map((o) => o.trim())).size === 4 &&
      q.correctIndex >= 0 &&
      q.correctIndex <= 3
    );
  }
  return q.correctAnswer.trim().length > 0;
}

export async function POST(req: Request) {
  if (!isAuthorized(req)) return unauthorized();
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Невалидна заявка." }, { status: 400 });
  const { subject, topic, type, recent } = parsed.data;

  // Темата трябва да е от конспекта – AI-ят не избира сам.
  if (!topicsFor(subject).includes(topic)) {
    return Response.json({ error: "Темата не е от конспекта." }, { status: 400 });
  }

  const work = subject === "literatura" ? findWork(topic) : null;
  const subjectText =
    subject === "ezik"
      ? `ЕЗИК, тема: „${topic}“. Можеш да дадеш кратък откъс/изречение(я), които сам съставяш, или малка таблица/данни от диаграма, описани с текст.`
      : `ЛИТЕРАТУРА, произведение: ${topic} (${work?.work.genre}), тематично ядро „${work?.core.name}“. Питай за смисъл, мотиви, образи, герои, конфликт, жанр, художествени средства, връзка с тематичното ядро. Цитирай откъс САМО ако си напълно сигурен в точния текст; иначе остави passage празен.`;

  const typeText =
    type === "mc"
      ? "Тип: задача с ИЗБИРАЕМ отговор – точно 4 правдоподобни варианта, само един верен. Вариантите да са без буквите а), б), в), г). Сменяй позицията на верния отговор."
      : "Тип: задача с КРАТЪК СВОБОДЕН отговор – отговорът е дума, израз, поправена дума/изречение или едно кратко изречение. options = [], correctIndex = -1. В acceptableAnswers дай приемливи варианти.";

  const recentText = recent.length
    ? `\nНЕ повтаряй тези вече зададени въпроси:\n${recent.map((r) => `- ${r}`).join("\n")}`
    : "";

  try {
    for (let i = 0; i < 2; i++) {
      const q = await askJson({
        schema: QuestionSchema,
        task: "Задача: създай ЕДНА тестова задача в стила на ДЗИ по БЕЛ. Върни я като JSON по схемата.",
        messages: [
          {
            role: "user",
            content: `${subjectText}\n${typeText}\nВ полето topic върни точно: ${topic}${recentText}`,
          },
        ],
        effort: "low",
      });
      if (isValid(q, type)) {
        const question: Question = {
          ...q,
          topic, // етикетът винаги е от кода, не от AI-я
          type,
          subject,
          options: type === "mc" ? q.options.map((o) => o.replace(/^\s*[абвгabcd][).]\s*/i, "")) : [],
          correctIndex: type === "mc" ? q.correctIndex : -1,
          correctAnswer: type === "mc" ? q.options[q.correctIndex] : q.correctAnswer,
        };
        return Response.json(question);
      }
    }
    return Response.json({ error: "AI учителят върна невалиден въпрос. Опитай пак." }, { status: 502 });
  } catch (err) {
    return errorResponse(err);
  }
}
