import { z } from "zod";
import { askJson, errorResponse } from "@/lib/ai";
import { isAuthorized, unauthorized } from "@/lib/auth";
import { OralSchema } from "@/lib/schemas";
import { findWork, topicsFor, SUBJECT_LABEL } from "@/data/syllabus";

export const maxDuration = 60;

const Body = z.object({
  history: z
    .array(z.object({ role: z.enum(["teacher", "student"]), text: z.string().max(6000) }))
    .max(60),
  nextSubject: z.enum(["ezik", "literatura"]),
  nextTopic: z.string().max(200),
});

export async function POST(req: Request) {
  if (!isAuthorized(req)) return unauthorized();
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Невалидна заявка." }, { status: 400 });
  const { history, nextSubject, nextTopic } = parsed.data;
  if (!topicsFor(nextSubject).includes(nextTopic)) {
    return Response.json({ error: "Темата не е от конспекта." }, { status: 400 });
  }

  const recent = history.slice(-16);
  const transcript = recent.length
    ? recent.map((m) => `${m.role === "teacher" ? "УЧИТЕЛ" : "УЧЕНИЧКА"}: ${m.text}`).join("\n\n")
    : "(изпитът тепърва започва)";
  const lastIsStudent = recent.at(-1)?.role === "student";
  const work = nextSubject === "literatura" ? findWork(nextTopic) : null;
  const topicText = work
    ? `${nextTopic} (${work.work.genre}, тематично ядро „${work.core.name}“)`
    : nextTopic;

  try {
    const turn = await askJson({
      schema: OralSchema,
      task: `Задача: водиш устен изпит. Задаваш по ЕДИН въпрос, ученичката отговаря свободно.
${lastIsStudent ? "1) Оцени последния ѝ отговор (verdict + feedback): какво е вярно, какво липсва, кратко дай верния отговор, ако е сгрешила. Бъди насърчителен, но честен." : "1) Още няма отговор – verdict = „няма“, feedback = празен низ (или кратък поздрав)."}
2) Задай следващия въпрос (nextQuestion) – ${SUBJECT_LABEL[nextSubject].toUpperCase()}, тема: ${topicText}. Въпросът да е ясен, отворен и да може да се отговори в 2–6 изречения. Не повтаряй вече зададени въпроси.`,
      messages: [{ role: "user", content: `Разговор досега:\n\n${transcript}` }],
      effort: "low",
      maxTokens: 4000,
    });
    if (!lastIsStudent) turn.verdict = "няма";
    return Response.json(turn);
  } catch (err) {
    return errorResponse(err);
  }
}
