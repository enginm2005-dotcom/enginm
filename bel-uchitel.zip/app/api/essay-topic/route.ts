import { z } from "zod";
import { askJson, errorResponse } from "@/lib/ai";
import { isAuthorized, unauthorized } from "@/lib/auth";
import { EssayTopicSchema } from "@/lib/schemas";
import { literature, workLabel } from "@/data/syllabus";

export const maxDuration = 60;

const Body = z.object({ kind: z.enum(["interpretative", "essay"]) });

export async function POST(req: Request) {
  if (!isAuthorized(req)) return unauthorized();
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Невалидна заявка." }, { status: 400 });
  const { kind } = parsed.data;

  // Произведението/ядрото се избира от кода на случаен принцип.
  const core = literature[Math.floor(Math.random() * literature.length)];
  const work = core.works[Math.floor(Math.random() * core.works.length)];

  const instruction =
    kind === "interpretative"
      ? `Създай тема за ИНТЕРПРЕТАТИВНО СЪЧИНЕНИЕ върху произведението ${workLabel(work)} (тематично ядро „${core.name}“). Формулировката да е като на ДЗИ, напр. „Образът на … в …“ или „Смисълът на … в …“.`
      : `Създай тема за ЕСЕ, свързана с тематичното ядро „${core.name}“. Темата е формулирана като кратка мисъл, въпрос или цитат, напр. „Можем ли да избягаме от миналото си?“. Есето е свободно разсъждение с аргументи от живота и литературата.`;

  try {
    const t = await askJson({
      schema: EssayTopicSchema,
      task: "Задача: формулирай тема за писмена работа в стила на ДЗИ по БЕЛ.",
      messages: [{ role: "user", content: instruction }],
      effort: "low",
      maxTokens: 2000,
    });
    return Response.json(t);
  } catch (err) {
    return errorResponse(err);
  }
}
