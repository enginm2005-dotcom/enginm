import { z } from "zod";
import { askJson, errorResponse } from "@/lib/ai";
import { isAuthorized, unauthorized } from "@/lib/auth";
import { EssayCheckSchema } from "@/lib/schemas";

export const maxDuration = 300;

const Body = z.object({
  kind: z.enum(["interpretative", "essay"]),
  topic: z.string().min(3).max(600),
  text: z.string().min(50).max(20000),
});

const CRITERIA = [
  ["Разбиране на темата", 5],
  ["Теза", 4],
  ["Аргументация и познаване на текста", 8],
  ["Композиция и свързаност", 4],
  ["Стил и лексика", 3],
  ["Правопис", 2],
  ["Пунктуация", 2],
  ["Граматика", 2],
] as const;

export async function POST(req: Request) {
  if (!isAuthorized(req)) return unauthorized();
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return Response.json({ error: "Текстът е твърде кратък или твърде дълъг." }, { status: 400 });
  }
  const { kind, topic, text } = parsed.data;
  const kindLabel = kind === "interpretative" ? "интерпретативно съчинение" : "есе";

  try {
    const result = await askJson({
      schema: EssayCheckSchema,
      task: `Задача: оцени ${kindLabel} по критериите на ДЗИ (общо 30 точки). Оценявай по тези критерии, в този ред и с тези максимуми:
${CRITERIA.map(([n, m]) => `- ${n}: 0–${m} т.`).join("\n")}
Изисквания:
- Бъди честен като истински проверител – не надценявай.
- В errors цитирай ТОЧНО откъса от текста с грешката (copy-paste), дай поправка и кратко правило. Изброй всички важни правописни, пунктуационни и граматични грешки (до 25).
- ${kind === "interpretative" ? "Провери дали тезата е обвързана с произведението и дали се интерпретира текстът, а не се преразказва." : "Провери дали има ясна позиция, аргументи от живота и литературата и личен глас."}
- Ако текстът не е по темата, кажи го ясно и оцени ниско „Разбиране на темата“.
- В weakTopics дай кратки етикети (напр. „пунктуация при подчинени изречения“ или името на произведението).`,
      messages: [{ role: "user", content: `Вид: ${kindLabel}\nТема: ${topic}\n\nТЕКСТ:\n${text}` }],
      effort: "medium",
      maxTokens: 16000,
    });

    // Точките се ограничават в кода по официалните максимуми.
    const criteria = CRITERIA.map(([name, max], i) => {
      const c = result.criteria.find((x) => x.name === name) ?? result.criteria[i];
      const points = Math.max(0, Math.min(max, Math.round((c?.points ?? 0) * 2) / 2));
      return { name, max, points, comment: c?.comment ?? "" };
    });
    const total = criteria.reduce((s, c) => s + c.points, 0);
    return Response.json({ ...result, criteria, total });
  } catch (err) {
    return errorResponse(err);
  }
}
