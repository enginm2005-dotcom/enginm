import { z } from "zod";
import { askJson, errorResponse } from "@/lib/ai";
import { isAuthorized, unauthorized } from "@/lib/auth";
import { GradeSchema } from "@/lib/schemas";

export const maxDuration = 60;

const Body = z.object({
  passage: z.string().max(4000).default(""),
  question: z.string().max(2000),
  correctAnswer: z.string().max(1000),
  acceptableAnswers: z.array(z.string().max(500)).max(20).default([]),
  userAnswer: z.string().max(2000),
});

export async function POST(req: Request) {
  if (!isAuthorized(req)) return unauthorized();
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Невалидна заявка." }, { status: 400 });
  const b = parsed.data;
  try {
    const grade = await askJson({
      schema: GradeSchema,
      task:
        "Задача: провери краткия свободен отговор на ученичката. Приеми го за верен, ако по смисъл съвпада с верния отговор (при задачи за правопис и пунктуация – само ако написаното е правилно). Бъди справедлив, но не прекалено строг към формулировката.",
      messages: [
        {
          role: "user",
          content:
            (b.passage ? `Откъс:\n${b.passage}\n\n` : "") +
            `Задача: ${b.question}\nВерен отговор: ${b.correctAnswer}\n` +
            (b.acceptableAnswers.length ? `Приемливи варианти: ${b.acceptableAnswers.join("; ")}\n` : "") +
            `Отговор на ученичката: ${b.userAnswer}`,
        },
      ],
      effort: "low",
      maxTokens: 2000,
    });
    return Response.json(grade);
  } catch (err) {
    return errorResponse(err);
  }
}
