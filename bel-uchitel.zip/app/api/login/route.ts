import { isAuthorized, unauthorized } from "@/lib/auth";

export async function POST(req: Request) {
  if (!process.env.APP_PASSWORD) {
    return Response.json({ error: "На сървъра не е зададена APP_PASSWORD." }, { status: 500 });
  }
  if (!isAuthorized(req)) return unauthorized();
  return Response.json({ ok: true });
}
