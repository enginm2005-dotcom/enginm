"use client";

import { useEffect, useState } from "react";
import { loadProgress, weakTopics, type Progress } from "@/lib/client";
import type { Screen } from "@/app/page";
import { ThemeToggle } from "./ui";

function pct(s: { correct: number; total: number }) {
  return s.total ? `${Math.round((100 * s.correct) / s.total)}%` : "–";
}

export default function Home({ go }: { go: (s: Screen) => void }) {
  const [progress, setProgress] = useState<Progress | null>(null);
  const [weak, setWeak] = useState<string[]>([]);

  useEffect(() => {
    setProgress(loadProgress());
    setWeak(weakTopics(3).map((w) => w.topic));
  }, []);

  const big = [
    { s: "test" as const, emoji: "📝", title: "Тест", sub: "30 въпроса · 15 език + 15 литература" },
    { s: "oral" as const, emoji: "🎤", title: "Изпитай ме", sub: "Устен изпит с AI учителя" },
    { s: "essay" as const, emoji: "✍️", title: "Провери ми есето", sub: "Оценка от 30 точки по критериите на ДЗИ" },
  ];

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-2xl flex-col px-4 pb-10 pt-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold sm:text-3xl">AI учител по БЕЛ</h1>
          <p className="text-stone-500 dark:text-stone-400">Подготовка за ДЗИ · матура</p>
        </div>
        <ThemeToggle />
      </div>

      <div className="mt-6 grid gap-4">
        {big.map((b) => (
          <button
            key={b.s}
            onClick={() => go(b.s)}
            className="group flex items-center gap-4 rounded-3xl border border-stone-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-0.5 hover:border-teal-500 hover:shadow-md active:translate-y-0 sm:p-6 dark:border-stone-800 dark:bg-stone-900 dark:hover:border-teal-500"
          >
            <span className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-teal-50 text-4xl dark:bg-teal-950">
              {b.emoji}
            </span>
            <span>
              <span className="block text-xl font-semibold sm:text-2xl">{b.title}</span>
              <span className="block text-stone-500 dark:text-stone-400">{b.sub}</span>
            </span>
          </button>
        ))}
      </div>

      <button
        onClick={() => go("weak")}
        className="mt-6 rounded-2xl border border-stone-200 bg-stone-100 p-4 text-left transition hover:border-teal-500 dark:border-stone-800 dark:bg-stone-900/60"
      >
        <div className="flex items-center justify-between">
          <span className="font-semibold">🎯 Слаби места</span>
          {progress && (
            <span className="text-sm text-stone-500 dark:text-stone-400">
              Език {pct(progress.stats.ezik)} · Литература {pct(progress.stats.literatura)}
            </span>
          )}
        </div>
        <p className="mt-1 truncate text-sm text-stone-600 dark:text-stone-400">
          {weak.length ? weak.join(" · ") : "Все още няма – започни с тест!"}
        </p>
      </button>
    </main>
  );
}
