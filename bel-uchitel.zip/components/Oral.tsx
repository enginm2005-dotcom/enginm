"use client";

import { useEffect, useRef, useState } from "react";
import type { OralTurn } from "@/lib/schemas";
import type { Subject } from "@/data/syllabus";
import { api, pickTopic, recordResult } from "@/lib/client";
import { Button, ErrorBox, Header, SubjectCounter, SubjectTag } from "./ui";

type Msg =
  | { role: "teacher"; text: string; subject?: Subject; topic?: string; verdict?: OralTurn["verdict"]; feedback?: string }
  | { role: "student"; text: string };

const VERDICT_STYLE: Record<string, string> = {
  вярно: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200",
  частично: "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200",
  грешно: "bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-200",
};
const VERDICT_ICON: Record<string, string> = { вярно: "✅", частично: "🟡", грешно: "❌" };

export default function Oral({ onExit }: { onExit: () => void }) {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [counts, setCounts] = useState({ ezik: 0, literatura: 0 });
  const current = useRef<{ subject: Subject; topic: string } | null>(null);
  const recentTopics = useRef<string[]>([]);
  const bottom = useRef<HTMLDivElement>(null);
  const started = useRef(false);

  // Предметът на следващия въпрос: строго редуване (контролира се от кода).
  const nextSubject = (): Subject => (counts.ezik <= counts.literatura ? "ezik" : "literatura");

  const askTeacher = async (history: Msg[]) => {
    const subject = nextSubject();
    const topic = pickTopic(subject, recentTopics.current.slice(-8));
    setLoading(true);
    setError("");
    try {
      const turn = await api<OralTurn>("/api/oral", {
        history: history.map((m) => ({
          role: m.role,
          text: m.role === "teacher" ? [m.feedback, m.text].filter(Boolean).join("\n") : m.text,
        })),
        nextSubject: subject,
        nextTopic: topic,
      });
      // Записваме оценката на предишния отговор към темата на предишния въпрос.
      if (turn.verdict !== "няма" && current.current) {
        recordResult(current.current.subject, current.current.topic, turn.verdict === "вярно");
      }
      current.current = { subject, topic };
      recentTopics.current.push(topic);
      setCounts((c) => ({ ...c, [subject]: c[subject] + 1 }));
      setMsgs([
        ...history,
        {
          role: "teacher",
          text: turn.nextQuestion,
          subject,
          topic,
          verdict: turn.verdict,
          feedback: turn.verdict !== "няма" ? turn.feedback : undefined,
        },
      ]);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    askTeacher([]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [msgs, loading]);

  const send = (text: string) => {
    const t = text.trim();
    if (!t || loading) return;
    const history: Msg[] = [...msgs, { role: "student", text: t }];
    setMsgs(history);
    setInput("");
    askTeacher(history);
  };

  const retry = () => {
    askTeacher(msgs);
  };

  return (
    <div className="flex h-dvh flex-col">
      <Header title="Изпитай ме" onBack={onExit} />
      <div className="mx-auto w-full max-w-2xl px-4 pt-3">
        <SubjectCounter ezik={counts.ezik} literatura={counts.literatura} />
      </div>

      <div className="mx-auto w-full max-w-2xl flex-1 overflow-y-auto px-4 py-4">
        <div className="space-y-4">
          {msgs.map((m, i) =>
            m.role === "teacher" ? (
              <div key={i} className="max-w-[92%] space-y-2">
                {m.feedback && m.verdict && m.verdict !== "няма" && (
                  <div className={`rounded-2xl rounded-tl-sm p-3 ${VERDICT_STYLE[m.verdict]}`}>
                    <p className="font-semibold">
                      {VERDICT_ICON[m.verdict]} {m.verdict[0].toUpperCase() + m.verdict.slice(1)}
                    </p>
                    <p className="mt-1 whitespace-pre-line">{m.feedback}</p>
                  </div>
                )}
                <div className="rounded-2xl rounded-tl-sm border border-stone-200 bg-white p-3 shadow-sm dark:border-stone-800 dark:bg-stone-900">
                  {m.subject && (
                    <div className="mb-1 flex flex-wrap items-center gap-2">
                      <SubjectTag subject={m.subject} />
                      <span className="text-xs text-stone-500 dark:text-stone-400">{m.topic}</span>
                    </div>
                  )}
                  <p className="whitespace-pre-line text-[17px] leading-relaxed">{m.text}</p>
                </div>
              </div>
            ) : (
              <div key={i} className="ml-auto max-w-[85%] whitespace-pre-line rounded-2xl rounded-tr-sm bg-teal-700 p-3 text-white dark:bg-teal-600">
                {m.text}
              </div>
            ),
          )}
          {loading && (
            <div className="flex items-center gap-2 text-stone-500 dark:text-stone-400">
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-stone-300 border-t-teal-600" />
              Учителят мисли…
            </div>
          )}
          {error && <ErrorBox message={error} onRetry={retry} />}
          <div ref={bottom} />
        </div>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
        className="border-t border-stone-200 bg-stone-50 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 dark:border-stone-800 dark:bg-stone-950"
      >
        <div className="mx-auto flex max-w-2xl items-end gap-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey && window.matchMedia("(min-width: 640px)").matches) {
                e.preventDefault();
                send(input);
              }
            }}
            rows={2}
            placeholder="Твоят отговор…"
            disabled={loading || msgs.length === 0}
            className="max-h-40 flex-1 resize-none rounded-xl border-2 border-stone-300 bg-white px-3 py-2 outline-none focus:border-teal-600 dark:border-stone-700 dark:bg-stone-900"
          />
          <div className="flex flex-col gap-1">
            <Button type="submit" disabled={loading || !input.trim()} className="px-4">
              ➤
            </Button>
          </div>
        </div>
        <div className="mx-auto mt-2 flex max-w-2xl">
          <Button variant="ghost" onClick={() => send("Не знам.")} disabled={loading || msgs.length === 0} className="min-h-9 px-3 py-1 text-sm">
            🤷 Не знам
          </Button>
        </div>
      </form>
    </div>
  );
}
