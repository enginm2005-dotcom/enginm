"use client";

import { useEffect, useState } from "react";
import { loadProgress, resetProgress, weakTopics, type Progress } from "@/lib/client";
import { Button, Card, Header, Page, SubjectTag } from "./ui";

export default function Weak({ onExit }: { onExit: () => void }) {
  const [progress, setProgress] = useState<Progress | null>(null);
  const [list, setList] = useState<ReturnType<typeof weakTopics>>([]);

  const refresh = () => {
    setProgress(loadProgress());
    setList(weakTopics());
  };
  useEffect(refresh, []);

  const reset = () => {
    if (confirm("Да изтрия ли целия прогрес?")) {
      resetProgress();
      refresh();
    }
  };

  const stat = (s: { correct: number; total: number }) => ({
    pct: s.total ? Math.round((100 * s.correct) / s.total) : null,
    text: `${s.correct} от ${s.total} верни`,
  });

  return (
    <>
      <Header title="Слаби места" onBack={onExit} />
      <Page>
        {progress && (
          <div className="grid grid-cols-2 gap-3">
            {(["ezik", "literatura"] as const).map((s) => {
              const st = stat(progress.stats[s]);
              return (
                <Card key={s} className="text-center">
                  <SubjectTag subject={s} />
                  <p className="mt-2 text-4xl font-bold">{st.pct === null ? "–" : `${st.pct}%`}</p>
                  <p className="text-sm text-stone-500 dark:text-stone-400">{st.text}</p>
                </Card>
              );
            })}
          </div>
        )}

        <Card className="mt-4">
          <h2 className="mb-1 text-lg font-semibold">Теми за повторение</h2>
          <p className="mb-3 text-sm text-stone-500 dark:text-stone-400">
            Тези теми се появяват по-често в теста и на устния изпит.
          </p>
          {list.length === 0 ? (
            <p>Няма слаби теми засега. 🎉</p>
          ) : (
            <ul className="divide-y divide-stone-200 dark:divide-stone-800">
              {list.map(({ topic, stat, pct }) => (
                <li key={topic} className="flex items-center gap-3 py-3">
                  <SubjectTag subject={stat.subject} />
                  <span className="flex-1">{topic}</span>
                  <span className="whitespace-nowrap text-sm text-stone-500 dark:text-stone-400">
                    {stat.wrong} гр. · {pct}%
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Button variant="ghost" onClick={reset} className="mt-6 w-full text-sm">
          Изчисти прогреса
        </Button>
      </Page>
    </>
  );
}
