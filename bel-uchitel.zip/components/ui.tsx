"use client";

import { useEffect, useState } from "react";

export function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => setDark(document.documentElement.classList.contains("dark")), []);
  const toggle = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    try {
      localStorage.setItem("bel.theme", next ? "dark" : "light");
    } catch {}
  };
  return (
    <button
      onClick={toggle}
      aria-label={dark ? "Светъл режим" : "Тъмен режим"}
      className="grid h-11 w-11 place-items-center rounded-full text-xl transition hover:bg-stone-200 dark:hover:bg-stone-800"
    >
      {dark ? "☀️" : "🌙"}
    </button>
  );
}

export function Header({ title, onBack, right }: { title: string; onBack?: () => void; right?: React.ReactNode }) {
  return (
    <header className="sticky top-0 z-10 border-b border-stone-200 bg-stone-50/90 backdrop-blur dark:border-stone-800 dark:bg-stone-950/90">
      <div className="mx-auto flex max-w-2xl items-center gap-2 px-3 py-2">
        {onBack ? (
          <button
            onClick={onBack}
            aria-label="Назад"
            className="grid h-11 w-11 place-items-center rounded-full text-2xl transition hover:bg-stone-200 dark:hover:bg-stone-800"
          >
            ←
          </button>
        ) : (
          <span className="w-2" />
        )}
        <h1 className="flex-1 truncate text-lg font-semibold">{title}</h1>
        {right}
        <ThemeToggle />
      </div>
    </header>
  );
}

export function Page({ children }: { children: React.ReactNode }) {
  return <main className="mx-auto w-full max-w-2xl px-4 pb-16 pt-4">{children}</main>;
}

export function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={`rounded-2xl border border-stone-200 bg-white p-4 shadow-sm sm:p-5 dark:border-stone-800 dark:bg-stone-900 ${className}`}
    >
      {children}
    </div>
  );
}

export function Button({
  children,
  onClick,
  disabled,
  variant = "primary",
  className = "",
  type = "button",
}: {
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  variant?: "primary" | "secondary" | "ghost";
  className?: string;
  type?: "button" | "submit";
}) {
  const styles = {
    primary: "bg-teal-700 text-white hover:bg-teal-800 dark:bg-teal-600 dark:hover:bg-teal-500",
    secondary:
      "border border-stone-300 bg-white text-stone-800 hover:bg-stone-100 dark:border-stone-700 dark:bg-stone-900 dark:text-stone-100 dark:hover:bg-stone-800",
    ghost: "text-stone-600 hover:bg-stone-200 dark:text-stone-300 dark:hover:bg-stone-800",
  }[variant];
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`min-h-12 rounded-xl px-5 py-3 text-base font-medium transition disabled:cursor-not-allowed disabled:opacity-50 ${styles} ${className}`}
    >
      {children}
    </button>
  );
}

export function Spinner({ text = "Мисля…" }: { text?: string }) {
  return (
    <div className="flex items-center gap-3 py-6 text-stone-500 dark:text-stone-400" role="status">
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-stone-300 border-t-teal-600 dark:border-stone-700 dark:border-t-teal-400" />
      <span>{text}</span>
    </div>
  );
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-rose-800 dark:border-rose-900 dark:bg-rose-950/50 dark:text-rose-200">
      <p>{message}</p>
      {onRetry && (
        <Button variant="secondary" onClick={onRetry} className="mt-3">
          Опитай пак
        </Button>
      )}
    </div>
  );
}

export function SubjectCounter({ ezik, literatura, total }: { ezik: number; literatura: number; total?: number }) {
  return (
    <div className="flex gap-2 text-sm">
      <span className="rounded-full bg-sky-100 px-3 py-1 font-medium text-sky-800 dark:bg-sky-950 dark:text-sky-200">
        Език: {ezik}
        {total ? `/${total}` : ""}
      </span>
      <span className="rounded-full bg-amber-100 px-3 py-1 font-medium text-amber-800 dark:bg-amber-950 dark:text-amber-200">
        Литература: {literatura}
        {total ? `/${total}` : ""}
      </span>
    </div>
  );
}

export function SubjectTag({ subject }: { subject: "ezik" | "literatura" }) {
  return subject === "ezik" ? (
    <span className="rounded-md bg-sky-100 px-2 py-0.5 text-xs font-semibold uppercase tracking-wide text-sky-800 dark:bg-sky-950 dark:text-sky-200">
      Език
    </span>
  ) : (
    <span className="rounded-md bg-amber-100 px-2 py-0.5 text-xs font-semibold uppercase tracking-wide text-amber-800 dark:bg-amber-950 dark:text-amber-200">
      Литература
    </span>
  );
}
