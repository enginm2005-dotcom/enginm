"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { Question, Grade } from "@/lib/schemas";
import type { Subject } from "@/data/syllabus";
import { api, pickTopic, recordResult, shuffle, sixPointGrade } from "@/lib/client";
import { Button, Card, ErrorBox, Header, Page, Spinner, SubjectCounter, SubjectTag } from "./ui";

const TOTAL = 30;
const PER_SUBJECT = TOTAL / 2;
const LETTERS = ["а", "б", "в", "г"];
const POINTS = { mc: 1, short: 2 } as const;

type Slot = { subject: Subject; type: "mc" | "short" };
type Answer = { correct: boolean; given: string; feedback?: string };

/** План на теста: строго редуване език/литература; във всеки предмет 9 избираеми + 6 кратки. */
function makePlan(): Slot[] {
  const types = () => shuffle<Slot["type"]>([...Array(9).fill("mc"), ...Array(6).fill("short")]);
  const ez = types();
  const lit = types();
  return Array.from({ length: TOTAL }, (_, i) =>
    i % 2 === 0 ? { subject: "ezik", type: ez[i / 2] } : { subject: "literatura", type: lit[(i - 1) / 2] },
  );
}

function normalize(s: string) {
  return s.trim().replace(/\s+/g, " ").replace(/[.!]$/, "").toLowerCase();
}

export default function Test({ onExit }: { onExit: () => void }) {
  const [plan] = useState(makePlan);
  const [questions, setQuestions] = useState<(Question | undefined)[]>([]);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [idx, setIdx] = useState(0);
  const [error, setError] = useState("");
  const [shortInput, setShortInput] = useState("");
  const [checking, setChecking] = useState(false);
  const [done, setDone] = useState(false);

  const pending = useRef(new Map<number, Promise<Question>>());
  const usedTopics = useRef<Record<Subject, string[]>>({ ezik: [], literatura: [] });
  const askedTexts = useRef<string[]>([]);

  const ensure = useCallback(
    (i: number) => {
      if (i >= TOTAL || pending.current.has(i)) return pending.current.get(i);
      const slot = plan[i];
      const topic = pickTopic(slot.subject, usedTopics.current[slot.subject].slice(-8));
      usedTopics.current[slot.subject].push(topic);
      const p = api<Question>("/api/question", {
        subject: slot.subject,
        topic,
        type: slot.type,
        recent: askedTexts.current.slice(-20),
      });
      pending.current.set(i, p);
      p.then(
        (q) => {
          askedTexts.current.push(q.question.slice(0, 200));
          setQuestions((prev) => {
            const next = [...prev];
            next[i] = q;
            return next;
          });
        },
        () => pending.current.delete(i), // при грешка позволяваме нов опит
      );
      return p;
    },
    [plan],
  );

  // Зарежда текущия въпрос и предварително следващия.
  useEffect(() => {
    if (done) return;
    setError("");
    const p = ensure(idx);
    p?.then(
      () => ensure(idx + 1),
      (e: Error) => setError(e.message),
    );
  }, [idx, ensure, done]);

  const q = questions[idx];
  const answer = answers[idx];
  const slot = plan[idx];

  const answeredBy = (s: Subject) => answers.filter((a, i) => a && plan[i].subject === s).length;

  const finish = (a: Answer) => {
    setAnswers((prev) => {
      const next = [...prev];
      next[idx] = a;
      return next;
    });
    if (q) recordResult(q.subject, q.topic, a.correct);
  };

  const chooseOption = (i: number) => {
    if (!q || answer) return;
    finish({ correct: i === q.correctIndex, given: q.options[i] });
  };

  const checkShort = async () => {
    if (!q || answer || !shortInput.trim()) return;
    const given = shortInput.trim();
    const accepted = [q.correctAnswer, ...q.acceptableAnswers].map(normalize);
    if (accepted.includes(normalize(given))) {
      finish({ correct: true, given });
      return;
    }
    setChecking(true);
    try {
      const g = await api<Grade>("/api/grade", {
        passage: q.passage,
        question: q.question,
        correctAnswer: q.correctAnswer,
        acceptableAnswers: q.acceptableAnswers,
        userAnswer: given,
      });
      finish({ correct: g.correct, given, feedback: g.feedback });
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setChecking(false);
    }
  };

  const next = () => {
    setShortInput("");
    if (idx + 1 >= TOTAL) setDone(true);
    else setIdx(idx + 1);
    window.scrollTo(0, 0);
  };

  const exit = () => {
    if (done || answers.filter(Boolean).length === 0 || confirm("Да прекъсна ли теста? Резултатите до момента са записани.")) {
      onExit();
    }
  };

  if (done) return <Results plan={plan} questions={questions} answers={answers} onExit={onExit} />;

  return (
    <>
      <Header title={`Тест · въпрос ${idx + 1} от ${TOTAL}`} onBack={exit} />
      <Page>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <SubjectCounter ezik={answeredBy("ezik")} literatura={answeredBy("literatura")} total={PER_SUBJECT} />
        </div>
        <div className="mb-4 h-2 overflow-hidden rounded-full bg-stone-200 dark:bg-stone-800">
          <div className="h-full bg-teal-600 transition-all" style={{ width: `${(100 * answers.filter(Boolean).length) / TOTAL}%` }} />
        </div>

        {!q && !error && <Spinner text="Подготвям въпроса…" />}
        {error && !q && <ErrorBox message={error} onRetry={() => { setError(""); ensure(idx)?.catch((e: Error) => setError(e.message)); }} />}

        {q && (
          <Card>
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <SubjectTag subject={slot.subject} />
              <span className="text-xs text-stone-500 dark:text-stone-400">
                {q.type === "mc" ? "Избираем отговор · 1 т." : "Кратък отговор · 2 т."}
              </span>
            </div>
            <p className="mb-2 text-sm text-stone-500 dark:text-stone-400">{q.topic}</p>

            {q.passage && (
              <blockquote className="mb-4 whitespace-pre-line rounded-xl border-l-4 border-teal-600 bg-stone-50 p-3 text-[15px] leading-relaxed dark:bg-stone-950">
                {q.passage}
              </blockquote>
            )}
            <p className="mb-4 whitespace-pre-line text-lg font-medium leading-snug">{q.question}</p>

            {q.type === "mc" ? (
              <div className="grid gap-2">
                {q.options.map((opt, i) => {
                  let style =
                    "border-stone-300 hover:border-teal-600 hover:bg-teal-50 dark:border-stone-700 dark:hover:bg-teal-950/40";
                  if (answer) {
                    if (i === q.correctIndex)
                      style = "border-emerald-500 bg-emerald-50 dark:bg-emerald-950/50";
                    else if (opt === answer.given)
                      style = "border-rose-500 bg-rose-50 dark:bg-rose-950/50";
                    else style = "border-stone-200 opacity-60 dark:border-stone-800";
                  }
                  return (
                    <button
                      key={i}
                      onClick={() => chooseOption(i)}
                      disabled={!!answer}
                      className={`flex min-h-12 items-start gap-3 rounded-xl border-2 px-4 py-3 text-left transition ${style}`}
                    >
                      <span className="font-semibold">{LETTERS[i]})</span>
                      <span>{opt}</span>
                    </button>
                  );
                })}
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  checkShort();
                }}
                className="space-y-3"
              >
                <textarea
                  value={shortInput}
                  onChange={(e) => setShortInput(e.target.value)}
                  disabled={!!answer || checking}
                  rows={2}
                  placeholder="Напиши отговора си…"
                  className="w-full resize-y rounded-xl border-2 border-stone-300 bg-white px-4 py-3 outline-none focus:border-teal-600 dark:border-stone-700 dark:bg-stone-950"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      checkShort();
                    }
                  }}
                />
                {!answer && (
                  <Button type="submit" disabled={checking || !shortInput.trim()} className="w-full sm:w-auto">
                    {checking ? "Проверявам…" : "Провери"}
                  </Button>
                )}
                {error && q && !answer && <ErrorBox message={error} />}
              </form>
            )}

            {answer && (
              <div
                className={`mt-4 rounded-xl p-4 ${
                  answer.correct
                    ? "bg-emerald-50 text-emerald-900 dark:bg-emerald-950/50 dark:text-emerald-100"
                    : "bg-rose-50 text-rose-900 dark:bg-rose-950/50 dark:text-rose-100"
                }`}
              >
                <p className="text-lg font-semibold">{answer.correct ? "✅ Вярно!" : "❌ Грешно"}</p>
                {!answer.correct && (
                  <p className="mt-1">
                    Верен отговор: <strong>{q.correctAnswer}</strong>
                  </p>
                )}
                {answer.feedback && <p className="mt-2">{answer.feedback}</p>}
                <p className="mt-2 text-[15px] opacity-90">
                  <strong>Защо: </strong>
                  {q.explanation}
                </p>
              </div>
            )}

            {answer && (
              <Button onClick={next} className="mt-4 w-full">
                {idx + 1 >= TOTAL ? "Виж резултата" : "Следващ въпрос →"}
              </Button>
            )}
          </Card>
        )}
      </Page>
    </>
  );
}

function Results({
  plan,
  questions,
  answers,
  onExit,
}: {
  plan: Slot[];
  questions: (Question | undefined)[];
  answers: Answer[];
  onExit: () => void;
}) {
  let points = 0;
  let max = 0;
  const bySubject = { ezik: { c: 0, t: 0 }, literatura: { c: 0, t: 0 } };
  const wrongTopics = new Map<string, Subject>();
  plan.forEach((slot, i) => {
    const a = answers[i];
    if (!a) return;
    max += POINTS[slot.type];
    bySubject[slot.subject].t += 1;
    if (a.correct) {
      points += POINTS[slot.type];
      bySubject[slot.subject].c += 1;
    } else if (questions[i]) {
      wrongTopics.set(questions[i]!.topic, slot.subject);
    }
  });
  const grade = sixPointGrade(points, max);

  return (
    <>
      <Header title="Резултат" onBack={onExit} />
      <Page>
        <Card className="text-center">
          <p className="text-stone-500 dark:text-stone-400">Точки</p>
          <p className="text-5xl font-bold">
            {points}
            <span className="text-2xl text-stone-400"> / {max}</span>
          </p>
          <p className="mt-4 text-stone-500 dark:text-stone-400">Оценка (приблизително)</p>
          <p className="text-3xl font-bold text-teal-700 dark:text-teal-400">
            {grade.label} {grade.value.toFixed(2)}
          </p>
          <div className="mt-4 flex justify-center">
            <SubjectCounter
              ezik={bySubject.ezik.c}
              literatura={bySubject.literatura.c}
              total={bySubject.ezik.t || PER_SUBJECT}
            />
          </div>
          <p className="mt-2 text-xs text-stone-500">верни отговори по предмет</p>
        </Card>

        <Card className="mt-4">
          <h2 className="mb-2 text-lg font-semibold">📌 Какво да повториш</h2>
          {wrongTopics.size === 0 ? (
            <p>Браво! Нямаш грешки. 🎉</p>
          ) : (
            <ul className="space-y-2">
              {[...wrongTopics].map(([topic, subject]) => (
                <li key={topic} className="flex items-start gap-2">
                  <SubjectTag subject={subject} />
                  <span>{topic}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Button onClick={onExit} className="mt-6 w-full">
          Към началото
        </Button>
      </Page>
    </>
  );
}
