"use client";

import { useState } from "react";
import { setPassword, clearPassword } from "@/lib/client";
import { Button, ThemeToggle } from "./ui";

export default function Login({ onSuccess }: { onSuccess: () => void }) {
  const [pw, setPw] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pw.trim()) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/login", { method: "POST", headers: { "x-app-password": pw } });
      if (res.ok) {
        setPassword(pw);
        onSuccess();
      } else {
        clearPassword();
        const data = await res.json().catch(() => ({}));
        setError(data.error ?? "Грешна парола.");
      }
    } catch {
      setError("Няма връзка със сървъра.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="mx-auto flex min-h-dvh max-w-sm flex-col justify-center px-4">
      <div className="absolute right-3 top-3">
        <ThemeToggle />
      </div>
      <div className="mb-8 text-center">
        <div className="mb-3 text-5xl">📚</div>
        <h1 className="text-2xl font-bold">AI учител по БЕЛ</h1>
        <p className="mt-2 text-stone-500 dark:text-stone-400">Подготовка за матурата</p>
      </div>
      <form onSubmit={submit} className="space-y-3">
        <input
          type="password"
          value={pw}
          onChange={(e) => setPw(e.target.value)}
          placeholder="Парола"
          autoFocus
          autoComplete="current-password"
          className="w-full rounded-xl border border-stone-300 bg-white px-4 py-3 outline-none focus:border-teal-600 focus:ring-2 focus:ring-teal-600/30 dark:border-stone-700 dark:bg-stone-900"
        />
        {error && <p className="text-sm text-rose-600 dark:text-rose-400">{error}</p>}
        <Button type="submit" disabled={loading || !pw.trim()} className="w-full">
          {loading ? "Проверявам…" : "Влез"}
        </Button>
      </form>
    </main>
  );
}
