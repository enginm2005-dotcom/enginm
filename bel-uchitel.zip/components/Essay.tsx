"use client";

import { useEffect, useState } from "react";
import type { EssayCheck } from "@/lib/schemas";
import { api, normalizeLabel, recordResult } from "@/lib/client";
import { Button, Card, ErrorBox, Header, Page, Spinner } from "./ui";

type Kind = "interpretative" | "essay";
type Result = EssayCheck & { total: number };

const DRAFT_KEY = "bel.essay.draft";
const KIND_LABEL: Record<Kind, string> = { interpretative: "Интерпретативно съчинение", essay: "Есе" };

const ERROR_COLOR: Record<string, string> = {
  правопис: "bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-200",
  пунктуация: "bg-violet-100 text-violet-800 dark:bg-violet-950 dark:text-violet-200",
  граматика: "bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-200",
  лексика: "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200",
  стил: "bg-stone-200 text-stone-800 dark:bg-stone-800 dark:text-stone-200",
  съдържание: "bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-200",
};

export default function Essay({ onExit }: { onExit: () => void }) {
  const [kind, setKind] = useState<Kind | null>(null);
  const [topic, setTopic] = useState("");
  const [hint, setHint] = useState("");
  const [text, setText] = useState("");
  const [loadingTopic, setLoadingTopic] = useState(false);
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<Result | null>(null);

  // Черновата се пази в браузъра, за да не се загуби текстът.
  useEffect(() => {
    try {
      const d = JSON.parse(localStorage.getItem(DRAFT_KEY) ?? "null");
      if (d?.text) {
        setKind(d.kind);
        setTopic(d.topic ?? "");
        setText(d.text);
      }
    } catch {}
  }, []);
  useEffect(() => {
    try {
      if (kind && text) localStorage.setItem(DRAFT_KEY, JSON.stringify({ kind, topic, text }));
    } catch {}
  }, [kind, topic, text]);

  const words = text.trim() ? text.trim().split(/\s+/).length : 0;

  const getTopic = async () => {
    if (!kind) return;
    setLoadingTopic(true);
    setError("");
    try {
      const t = await api<{ topic: string; hint: string }>("/api/essay-topic", { kind });
      setTopic(t.topic);
      setHint(t.hint);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoadingTopic(false);
    }
  };

  const check = async () => {
    if (!kind || !topic.trim() || words < 30) return;
    setChecking(true);
    setError("");
    try {
      const r = await api<Result>("/api/essay-check", { kind, topic, text });
      setResult(r);
      for (const label of r.weakTopics) {
        const { subject, topic: t } = normalizeLabel(label);
        recordResult(subject, t, false, false);
      }
      window.scrollTo(0, 0);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setChecking(false);
    }
  };

  const startOver = () => {
    setResult(null);
    setText("");
    setTopic("");
    setHint("");
    setKind(null);
    try {
      localStorage.removeItem(DRAFT_KEY);
    } catch {}
  };

  if (result) {
    return (
      <>
        <Header title="Оценка на текста" onBack={onExit} />
        <Page>
          <Card className="text-center">
            <p className="text-stone-500 dark:text-stone-400">{kind && KIND_LABEL[kind]}</p>
            <p className="mt-1 text-5xl font-bold">
              {result.total}
              <span className="text-2xl text-stone-400"> / 30</span>
            </p>
            <p className="mt-3 text-left text-[15px] leading-relaxed">{result.summary}</p>
          </Card>

          <Card className="mt-4">
            <h2 className="mb-3 text-lg font-semibold">Критерии</h2>
            <div className="space-y-4">
              {result.criteria.map((c) => (
                <div key={c.name}>
                  <div className="flex justify-between text-[15px]">
                    <span className="font-medium">{c.name}</span>
                    <span className="font-semibold">
                      {c.points} / {c.max}
                    </span>
                  </div>
                  <div className="mt-1 h-2 overflow-hidden rounded-full bg-stone-200 dark:bg-stone-800">
                    <div className="h-full rounded-full bg-teal-600" style={{ width: `${(100 * c.points) / c.max}%` }} />
                  </div>
                  {c.comment && <p className="mt-1 text-sm text-stone-600 dark:text-stone-400">{c.comment}</p>}
                </div>
              ))}
            </div>
          </Card>

          {result.errors.length > 0 && (
            <Card className="mt-4">
              <h2 className="mb-3 text-lg font-semibold">Грешки ({result.errors.length})</h2>
              <ul className="space-y-3">
                {result.errors.map((e, i) => (
                  <li key={i} className="rounded-xl border border-stone-200 p-3 dark:border-stone-800">
                    <span className={`rounded-md px-2 py-0.5 text-xs font-semibold ${ERROR_COLOR[e.kind] ?? ""}`}>{e.kind}</span>
                    <p className="mt-2">
                      <span className="text-rose-700 line-through decoration-rose-400 dark:text-rose-300">{e.quote}</span>
                      <span className="mx-2">→</span>
                      <span className="font-medium text-emerald-700 dark:text-emerald-300">{e.fix}</span>
                    </p>
                    <p className="mt-1 text-sm text-stone-600 dark:text-stone-400">{e.why}</p>
                  </li>
                ))}
              </ul>
            </Card>
          )}

          {result.strengths.length > 0 && (
            <Card className="mt-4">
              <h2 className="mb-2 text-lg font-semibold">👍 Силни страни</h2>
              <ul className="list-disc space-y-1 pl-5">
                {result.strengths.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </Card>
          )}

          <Card className="mt-4">
            <h2 className="mb-2 text-lg font-semibold">🛠 Как да подобриш</h2>
            <ul className="list-disc space-y-1 pl-5">
              {result.improvements.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ul>
          </Card>

          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <Button variant="secondary" onClick={() => setResult(null)}>
              ← Редактирай текста
            </Button>
            <Button onClick={startOver}>Нова тема</Button>
          </div>
        </Page>
      </>
    );
  }

  if (!kind) {
    return (
      <>
        <Header title="Провери ми есето" onBack={onExit} />
        <Page>
          <p className="mb-4 text-stone-600 dark:text-stone-400">Какво ще пишеш?</p>
          <div className="grid gap-4">
            {(["interpretative", "essay"] as Kind[]).map((k) => (
              <button
                key={k}
                onClick={() => setKind(k)}
                className="rounded-3xl border border-stone-200 bg-white p-6 text-left shadow-sm transition hover:border-teal-500 dark:border-stone-800 dark:bg-stone-900"
              >
                <span className="block text-xl font-semibold">{k === "interpretative" ? "📖 " : "💭 "}{KIND_LABEL[k]}</span>
                <span className="mt-1 block text-stone-500 dark:text-stone-400">
                  {k === "interpretative"
                    ? "Тълкуване на литературно произведение"
                    : "Свободно разсъждение по проблем с аргументи"}
                </span>
              </button>
            ))}
          </div>
        </Page>
      </>
    );
  }

  return (
    <>
      <Header title={KIND_LABEL[kind]} onBack={onExit} />
      <Page>
        <Card>
          <label className="mb-2 block font-semibold" htmlFor="topic">
            Тема
          </label>
          <textarea
            id="topic"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            rows={2}
            placeholder="Напиши своя тема или натисни „Дай ми тема“"
            className="w-full resize-y rounded-xl border-2 border-stone-300 bg-white px-3 py-2 outline-none focus:border-teal-600 dark:border-stone-700 dark:bg-stone-950"
          />
          {hint && <p className="mt-2 text-sm text-stone-600 dark:text-stone-400">💡 {hint}</p>}
          <div className="mt-3 flex flex-wrap gap-2">
            <Button variant="secondary" onClick={getTopic} disabled={loadingTopic}>
              {loadingTopic ? "Измислям…" : "🎲 Дай ми тема"}
            </Button>
            <Button variant="ghost" onClick={startOver}>
              Смени вида
            </Button>
          </div>
        </Card>

        <div className="mt-4">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Пиши тук… (текстът се пази автоматично)"
            className="min-h-[55dvh] w-full resize-y rounded-2xl border-2 border-stone-300 bg-white p-4 text-[17px] leading-relaxed outline-none focus:border-teal-600 dark:border-stone-700 dark:bg-stone-900"
          />
          <p className="mt-1 text-right text-sm text-stone-500">{words} думи</p>
        </div>

        {error && <div className="mt-3"><ErrorBox message={error} /></div>}
        {checking ? (
          <Spinner text="Проверявам текста внимателно… (до минута)" />
        ) : (
          <Button onClick={check} disabled={!topic.trim() || words < 30} className="mt-3 w-full">
            Провери
          </Button>
        )}
        {words > 0 && words < 30 && <p className="mt-2 text-center text-sm text-stone-500">Напиши поне 30 думи.</p>}
      </Page>
    </>
  );
}
